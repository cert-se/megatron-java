package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS090 extends FeedOpsTest {

    public TestOpsRSS090() {
        super("rss_0.9");
    }

}
