package com.sun.syndication.unittest;

/**
 *
 * <p>
 * @author Alejandro Abdelnur
 *
 */
public class TestOpsRSS091U extends FeedOpsTest {

    public TestOpsRSS091U() {
        super("rss_0.91U");
    }

}
